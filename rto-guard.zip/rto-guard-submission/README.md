# RTO Guard - decide what to do with every COD order before it ships

Looks at each new Cash-on-Delivery order and picks one of four actions, with a plain-English reason:
**Ship as-is · Ship after WhatsApp confirmation · Nudge to prepaid · Hold / cancel**.

Business memo, decision log and AI usage log are in the repo root: `MEMO.pdf`, `DECISION_LOG.md`, `AI_USAGE_LOG.md`.

## Run it in under 10 minutes (Python 3.10+)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python run.py backtest        # trains on Apr-Aug, replays September, prints Rs impact (out/backtest_report.md)
python run.py dashboard       # builds out/dashboard.html  (open it in a browser)
python run.py decide KT100193 # one order -> action + reason
python run.py whatsapp-demo   # 10 scripted WhatsApp scenarios (yes / no / random / silence / late reply...)
python run.py chat            # browser chat simulator -> http://localhost:8765
python run.py findings        # every number quoted in the memo (out/findings.md)
python run.py discount        # prepaid-discount maths
python -m pytest -q tests     # 31 tests
```
Pre-generated outputs are already in `out/` so you can read results without running anything.
No API key is needed. (See "Where the LLM is used".)

## Changing the rules without touching code
Open **`config.yaml`**. Every threshold, cost, discount and WhatsApp timing is there with a plain comment. Edit a number, save, re-run `python run.py backtest` to see what it would have done to September.

| You want to... | Change |
|---|---|
| Cancel more/less | `thresholds.cancel_above_risk` |
| Send more/fewer WhatsApp confirmations | `thresholds.confirm_above_risk` |
| Offer prepaid discounts to more/fewer people | `thresholds.nudge_above_risk`, `prepaid_discount.*` |
| Let first-time customers be cancelled | `guardrails.never_auto_cancel_first_time: false` |
| Change what happens after 24h of silence | `whatsapp.on_no_reply_*` |

## How a decision is made
1. **Clean** the data (`data.py`): normalise status labels, drop 30 duplicate order IDs and 1 in-transit order, validate phones.
2. **Read the free text** (`llm.py`): is the address usable? is the name fake?
3. **Score risk** (`model.py`): small logistic regression on city, first-time vs repeat, past returns, order value, ad source and the text flags -> "chance this order comes back".
4. **Apply rules + thresholds** (`engine.py`, `config.yaml`) -> one of 4 actions. Hard rules first (unreachable customer, serial returner), then the risk thresholds, with the first-time-customer guardrail.
5. **Explain**: the top drivers are turned into a sentence using real history ("Gorakhpur orders came back 62% of the time (45 orders)").
6. **Money**: `economics.py` / `impact.py` put a Rs figure on every action vs just shipping.

## Where the LLM is used (and where it is not)
| LLM | Plain code / maths |
|---|---|
| Is this address complete and deliverable? (incl. Hinglish landmarks) | Phone validity, pincode/state match, order value |
| Is this name fake ("asdf", "Test Order")? | Customer history (prior orders/returns) |
| (Not the action - ever) | Historical return rates, risk score, thresholds, Rs maths, WhatsApp state machine, discount |

Reason: text judgement is where regexes fail and an LLM is cheap and good; anything with a right answer must be deterministic, auditable and free. The LLM returns a tiny JSON that becomes *one input* to the score; it cannot choose an action. If it times out we fall back to rules and never block an order.

**Honesty note:** the live Claude call (`ANTHROPIC_API_KEY` + `pip install anthropic`) was written to the SDK docs but **not run** during the build (no key available). Everything demonstrated here (tests, backtest, dashboard) uses the offline rule-based fallback. On this sample, rules catch all the junk addresses (they are obvious: ".", "xyz", "call me"), so the backtest shows the *rules'* value, not the LLM's; the LLM matters for the long tail in production.

## Folder map
```
config.yaml            <- the knobs
run.py                 <- CLI
rto_guard/{data,llm,model,engine,economics,impact,dashboard,discount,analysis,backtest}.py
rto_guard/whatsapp/{flow,simulator}.py
tests/test_all.py
out/                   <- backtest report, findings, dashboard.html, WhatsApp demo transcript, discount table
```

## Known limits
* ~2,000 orders / 6 months, one holdout month (329 orders). The AUC of 0.74 and the Rs figures are indicative, not precise.
* How customers react to WhatsApp messages and discounts is **unmeasured**; those inputs are guesses in `config.yaml -> assumptions` and the backtest shows results under pessimistic/optimistic values. Replace them with real numbers after ~2 weeks live.
* The dashboard "yesterday" is the last day in the CSV (30 Sep 2026). In production, point it at your orders feed.
* WhatsApp is a mock (state machine + simulator). Real sending needs the WhatsApp Cloud API and approved message templates.
* The dashboard estimates impact from the risk score (outcomes take ~10 days); the backtest uses actual outcomes, so the two Rs figures differ slightly.
