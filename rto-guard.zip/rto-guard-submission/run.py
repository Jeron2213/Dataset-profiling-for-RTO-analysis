"""RTO Guard CLI.   python run.py <command>
   backtest      train on Apr-Aug, replay September, print policy comparison (writes out/backtest_report.md)
   tune          grid-search thresholds on Apr-Aug out-of-fold scores
   findings      the numbers behind the memo (out/findings.md)
   dashboard     build out/dashboard.html for the latest day in the data (or --date 2026-09-30)
   decide ID     decide one order from the CSV, e.g. python run.py decide KT100193
   whatsapp-demo scripted WhatsApp scenarios       chat   browser chat simulator on :8765
   discount      the prepaid discount maths"""
import sys, os, yaml, copy
import numpy as np, pandas as pd
from rto_guard.data import load_orders
from rto_guard.model import RiskModel, add_text_signals
from rto_guard.backtest import decide_all, realised, policy_ship_all, split_time
from rto_guard.engine import SHIP, CONFIRM, NUDGE, HOLD, LABEL
from rto_guard.impact import summarise

CFG = "config.yaml"
DATA = "data/orders_sample.csv"
os.makedirs("out", exist_ok=True)

def load():
    rep = {}
    df = add_text_signals(load_orders(DATA, rep))
    return df, rep

def backtest(cfg):
    df, rep = load()
    train, test = split_time(df)
    model = RiskModel().fit(train)
    res = decide_all(test, model, cfg)
    from sklearn.metrics import roc_auc_score
    auc = roc_auc_score(test.rto, res.risk)
    scale = 3000 * 0.55 / len(test)       # sample month -> real COD volume (1,650 orders/month)
    L = []
    L.append(f"# Backtest: trained on Apr-Aug ({len(train)} orders), replayed on September ({len(test)} orders, {test.rto.mean():.1%} returned)\n")
    L.append(f"Risk model AUC on September (out of time): {auc:.2f}  (0.5 = coin flip, 1.0 = perfect)\n")
    g = res.groupby("action").agg(orders=("rto", "size"), actually_returned=("rto", "mean"), avg_risk=("risk", "mean"), avg_value=("order_value", "mean"))
    g = g.reindex([SHIP, CONFIRM, NUDGE, HOLD])
    g["actually_returned"] = g.actually_returned.map("{:.0%}".format); g["avg_risk"] = g.avg_risk.map("{:.0%}".format); g["avg_value"] = g.avg_value.map("Rs {:,.0f}".format)
    L.append(g.to_markdown() + "\n")
    # policies
    ship = policy_ship_all(test, cfg)
    ops = test.copy(); ops["action"] = np.where(res.risk >= 0.35, HOLD, SHIP)
    ops_gain = realised(ops, cfg).sum() - ship
    ops_n = (ops.action == HOLD).sum(); ops_first = ((ops.action == HOLD) & (ops.customer_prior_orders == 0)).sum()
    ops_ret = ops[ops.action == HOLD].rto.mean()
    res["v"] = realised(res, cfg)
    ours = res.v.sum() - ship
    L.append("## Policy comparison on September (Rs vs shipping every COD order as-is)\n")
    L.append("| Policy | Orders touched | Rs vs ship-all (sample month) | Rs vs ship-all (scaled to ~1,650 COD orders/month) |\n|---|---|---|---|")
    L.append(f"| Ship everything (Marketing's baseline) | 0 | 0 | 0 |")
    L.append(f"| Ops: cancel every order with risk >= 35% | {ops_n} cancelled ({ops_first} first-time, {ops_ret:.0%} of them would have returned) | {ops_gain:,.0f} | {ops_gain*scale:,.0f} |")
    L.append(f"| **Ours** (config.yaml) | {(res.action != SHIP).sum()} acted on, {(res.action == HOLD).sum()} cancelled | {ours:,.0f} | {ours*scale:,.0f} |")
    L.append(f"\nOps policy writes off {ops_first} first-time customers = Rs {ops_first*cfg['economics']['acquisition_cost_meta']:,} of acquisition spend (at Rs {cfg['economics']['acquisition_cost_meta']} each) in one month of sample data.\n")
    # sensitivity
    L.append("## Sensitivity: our policy's gain vs ship-all under different customer-behaviour guesses (sample month / scaled)\n")
    L.append("| Scenario | confirm drops real RTOs | confirm loses genuine | accept prepaid | Rs (sample) | Rs / month (scaled) |\n|---|---|---|---|---|---|")
    for name, a in {"Pessimistic": dict(nudge_conversion=0.10, confirm_drops_would_be_rto=0.40, confirm_drops_genuine=0.15),
                    "Base (config)": {}, "Optimistic": dict(nudge_conversion=0.35, confirm_drops_would_be_rto=0.70, confirm_drops_genuine=0.05),
                    "Nudge does nothing": dict(nudge_conversion=0.0)}.items():
        c = copy.deepcopy(cfg); c["assumptions"].update(a); A = c["assumptions"]
        r2 = res.copy(); gain = realised(r2, c).sum() - policy_ship_all(test, c)
        L.append(f"| {name} | {A['confirm_drops_would_be_rto']:.0%} | {A['confirm_drops_genuine']:.0%} | {A['nudge_conversion']:.0%} | {gain:,.0f} | {gain*scale:,.0f} |")
    # which rule contributes
    L.append("\n## Where the gain comes from (base assumptions, Rs vs shipping, sample month)\n")
    rows = []
    for rule, grp in res.groupby("rule"):
        sv = sum(__import__("rto_guard.economics", fromlist=["x"]).realised_value("ship", r.rto, r.order_value, r.customer_prior_orders == 0, cfg) for r in grp.itertuples())
        rows.append((rule, len(grp), f"{grp.rto.mean():.0%}", f"{grp.v.sum()-sv:,.0f}"))
    L.append(pd.DataFrame(rows, columns=["rule", "orders", "actually returned", "Rs vs shipping"]).to_markdown(index=False))
    # breakeven
    e = cfg["economics"]; from rto_guard import economics as eco
    Lr = eco.rto_loss(e)
    L.append("\n## Why cancelling is rarely worth it\n")
    L.append("| Order value | Margin if delivered | Cost of a return | Cancel only pays above this risk |\n|---|---|---|---|")
    for V in (449, 649, 920, 1500):
        mv = eco.margin(e, V); L.append(f"| Rs {V} | Rs {mv:.0f} | Rs {Lr:.0f} | {mv/(mv+Lr):.0%} |")
    txt = "\n".join(L); open("out/backtest_report.md", "w").write(txt); print(txt)
    res.to_csv("out/september_decisions.csv", index=False)

def dashboard(cfg, date=None):
    from rto_guard.dashboard import build
    df, rep = load()
    day = pd.Timestamp(date) if date else df.order_dt.max().normalize()
    start = day - pd.Timedelta(days=30)
    train = df[df.order_dt < start]; win = df[(df.order_dt >= start) & (df.order_dt < day + pd.Timedelta(days=1))]
    model = RiskModel().fit(train)
    res = decide_all(win, model, cfg)
    info = build(res, cfg, day, "out/dashboard.html")
    print("dashboard ->", "out/dashboard.html", info)

def tune(cfg):
    """Grid-search thresholds using OUT-OF-FOLD risk scores on Apr-Aug only (September stays untouched)."""
    import itertools
    from sklearn.model_selection import StratifiedKFold
    from rto_guard.engine import decide
    df, rep = load(); train, test = split_time(df)
    oof = pd.Series(0.0, index=train.index)
    for a, b in StratifiedKFold(5, shuffle=True, random_state=0).split(train, train.rto):
        oof.iloc[b] = RiskModel().fit(train.iloc[a]).predict(train.iloc[b])
    rows = []
    for cx, cf, nu in itertools.product([0.5, 0.6, 0.7, 0.75, 0.8, 0.95], [0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55], [0.1, 0.15, 0.2, 0.25, 0.3, 0.35]):
        if not nu < cf < cx: continue
        c = copy.deepcopy(cfg); c["thresholds"].update(cancel_above_risk=cx, confirm_above_risk=cf, nudge_above_risk=nu)
        t = train.copy(); t["action"] = [decide(r, p, [], c)["action"] for (_, r), p in zip(t.iterrows(), oof.values)]
        rows.append((realised(t, c).sum() - policy_ship_all(train, c), cx, cf, nu))
    top = pd.DataFrame(sorted(rows, reverse=True)[:10], columns=["Rs vs ship-all (Apr-Aug)", "cancel", "confirm", "nudge"])
    print(top.to_string(index=False))
    cur = [r for r in rows if (r[1], r[2], r[3]) == (cfg["thresholds"]["cancel_above_risk"], cfg["thresholds"]["confirm_above_risk"], cfg["thresholds"]["nudge_above_risk"])]
    print("\ncurrent config.yaml thresholds:", cur[0][0] if cur else "not on grid")

def decide_one(cfg, oid):
    df, rep = load()
    row = df[df.order_id == oid]
    if row.empty: sys.exit(f"{oid} not found")
    train = df[df.order_dt < row.order_dt.iloc[0]]
    model = RiskModel().fit(train if len(train) > 300 else df)
    r = decide_all(row, model, cfg).iloc[0]
    print(f"{r.order_id}: {r.label}\n{r.reason}\n(actual outcome: {'RETURNED' if r.rto else 'delivered'})")

if __name__ == "__main__":
    cfg = yaml.safe_load(open(CFG))
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "backtest": backtest(cfg)
    elif cmd == "findings":
        from rto_guard.analysis import findings
        df, rep = load(); t = findings(df, cfg, rep); open("out/findings.md", "w").write(t); print(t)
    elif cmd == "dashboard": dashboard(cfg, sys.argv[2] if len(sys.argv) > 2 else None)
    elif cmd == "tune": tune(cfg)
    elif cmd == "decide": decide_one(cfg, sys.argv[2])
    elif cmd == "whatsapp-demo":
        from rto_guard.whatsapp.simulator import demo; demo(cfg)
    elif cmd == "chat":
        from rto_guard.whatsapp.simulator import serve; serve(cfg)
    elif cmd == "discount":
        from rto_guard.discount import table; print(table(cfg))
    else: print(__doc__)
