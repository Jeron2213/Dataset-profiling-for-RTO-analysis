import sys, os, copy, yaml
from datetime import datetime, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pandas as pd
from rto_guard.engine import decide, SHIP, CONFIRM, NUDGE, HOLD
from rto_guard.whatsapp.flow import Conversation, next_send_time, classify
from rto_guard.data import load_orders
from rto_guard import economics as eco
from rto_guard.llm import heuristic_judge

CFG = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), "..", "config.yaml")))

def row(**kw):
    d = dict(customer_prior_orders=0, customer_prior_rto=0, order_value=700, addr_unusable=False, fake_name=False,
             phone_valid=True, customer_name="Asha Rao")
    d.update(kw); return pd.Series(d)

def test_thresholds_are_ordered():
    t = CFG["thresholds"]; assert t["nudge_above_risk"] < t["confirm_above_risk"] < t["cancel_above_risk"]

def test_low_risk_ships(): assert decide(row(), 0.10, [], CFG)["action"] == SHIP
def test_mid_risk_nudges(): assert decide(row(), 0.30, [], CFG)["action"] == NUDGE
def test_small_order_not_nudged(): assert decide(row(order_value=250), 0.30, [], CFG)["action"] == SHIP
def test_high_risk_confirms(): assert decide(row(customer_prior_orders=3), 0.50, [], CFG)["action"] == CONFIRM
def test_repeat_customer_very_high_risk_cancelled(): assert decide(row(customer_prior_orders=3), 0.85, [], CFG)["action"] == HOLD
def test_first_timer_never_auto_cancelled():
    r = decide(row(), 0.95, [], CFG); assert r["action"] == CONFIRM and "first-time" in r["reason"]
def test_junk_address_asks_to_fix_not_cancel():
    r = decide(row(addr_unusable=True), 0.64, [], CFG); assert r["action"] == CONFIRM
def test_junk_address_and_bad_phone_hold(): assert decide(row(addr_unusable=True, phone_valid=False), 0.6, [], CFG)["action"] == HOLD
def test_serial_returner_held(): assert decide(row(customer_prior_orders=4, customer_prior_rto=2), 0.7, [], CFG)["action"] == HOLD
def test_zero_value_ships(): assert decide(row(order_value=0), 0.3, [], CFG)["action"] == SHIP
def test_every_decision_has_reason():
    for p in (0.05, 0.3, 0.5, 0.9):
        assert len(decide(row(), p, ["x"], CFG)["reason"]) > 20

def test_config_change_changes_behaviour():
    c = copy.deepcopy(CFG); c["thresholds"]["confirm_above_risk"] = 0.25
    assert decide(row(customer_prior_orders=2), 0.30, [], c)["action"] == CONFIRM

def test_break_even():
    e = CFG["economics"]; assert abs(eco.rto_loss(e) - 169.4) < 0.01
    # at the break-even risk, shipping and cancelling are worth the same
    m = eco.margin(e, 649); p = m / (m + eco.rto_loss(e))
    assert abs(eco.expected_value("ship", p, 649, False, CFG)) < 1e-6

def test_discount_within_bounds():
    for v in (100, 649, 5000):
        d = eco.prepaid_discount_rs(CFG, v); assert CFG["prepaid_discount"]["min_rupees"] <= d <= CFG["prepaid_discount"]["max_rupees"]

# ---- WhatsApp
O = dict(order_id="X1", customer_name="Rahul Verma", state="Uttar Pradesh", city="Lucknow", order_value=649, items="A|B", address="call me")
T0 = datetime(2026, 10, 30, 14, 0)
def conv(flow, **o): return Conversation(dict(O, **o), flow, CFG, T0)

def test_quiet_hours_delay(): assert next_send_time(datetime(2026, 10, 30, 23, 30), CFG) == datetime(2026, 10, 31, 8, 0)
def test_language_by_state():
    assert conv("confirm").lang == "hi" and conv("confirm", state="Karnataka").lang == "en"
def test_classify():
    assert classify("Haan", "confirm") == "yes" and classify("nahi chahiye", "confirm") == "no" and classify("kab aayega", "confirm") == "unclear"
def test_yes_ships():
    c = conv("confirm"); c.on_message("yes", T0 + timedelta(hours=1)); assert c.final == "SHIP_COD"
def test_no_cancels():
    c = conv("confirm"); c.on_message("no", T0 + timedelta(hours=1)); assert c.final == "CANCELLED"
def test_random_then_random_goes_to_human():
    c = conv("confirm"); c.on_message("??", T0 + timedelta(hours=1)); assert c.final is None
    c.on_message("hello", T0 + timedelta(hours=2)); assert c.final == "HUMAN"
def test_silence_cancels_confirm_flow():
    c = conv("confirm"); c.tick(T0 + timedelta(hours=26)); assert c.final == "CANCELLED"
    assert sum("eminder" in t or "Aakhri" in t or "Last call" in t for _, _, t in c.log) == 2
def test_silence_ships_nudge_flow():
    c = conv("nudge"); c.tick(T0 + timedelta(hours=26)); assert c.final == "SHIP_COD"
def test_late_yes_revives():
    c = conv("confirm"); c.tick(T0 + timedelta(hours=26)); c.on_message("yes", T0 + timedelta(hours=40)); assert c.final == "SHIP_COD"
def test_nudge_accept_and_decline():
    a = conv("nudge"); a.on_message("1", T0 + timedelta(hours=1)); assert a.final == "SHIP_PREPAID_PENDING"
    b = conv("nudge"); b.on_message("2", T0 + timedelta(hours=1)); assert b.final == "SHIP_COD"
def test_nudge_message_shows_discount():
    c = conv("nudge"); c.tick(T0 + timedelta(minutes=10)); assert "₹32" in c.outbox[0][1] and "₹617" in c.outbox[0][1]
def test_fix_address():
    c = conv("fix"); c.on_message("Flat 402, Shanti Apt, Gomti Nagar, Lucknow 226010", T0 + timedelta(hours=1)); assert c.final == "SHIP_COD"
def test_stop_goes_to_human():
    c = conv("confirm"); c.on_message("STOP", T0 + timedelta(hours=1)); assert c.final == "HUMAN"

# ---- data + text judge
def test_cleaning():
    rep = {}; d = load_orders(os.path.join(os.path.dirname(__file__), "..", "data", "orders_sample.csv"), rep)
    assert set(d.status.unique()) == {"DELIVERED", "RTO"} and d.order_id.is_unique and rep["duplicate_rows_dropped"] == 30
def test_text_judge():
    assert heuristic_judge("Asha Rao", ".", "Delhi")["address_usable"] is False
    assert heuristic_judge("Test Order", "12/3 MG Road", "Pune")["fake_name"] is True
    assert heuristic_judge("Asha Rao", "Station chowk se left, Hanuman Mandir ke saamne", "Pune")["address_usable"] is True
def test_no_false_fake_names_on_real_data():
    d = load_orders(os.path.join(os.path.dirname(__file__), "..", "data", "orders_sample.csv"))
    flagged = d[[heuristic_judge(n, a, c)["fake_name"] for n, a, c in zip(d.customer_name, d.address, d.city)]]
    assert 30 <= len(flagged) <= 45, len(flagged)
