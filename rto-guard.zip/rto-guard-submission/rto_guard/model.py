"""Risk model: a small, readable logistic regression. Chosen over a bigger model because
(1) ~2,000 rows, (2) every decision must be explainable to an ops person, (3) it is fast."""
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from .llm import llm_judge

MIN_CITY_ORDERS = 25    # rarer cities are grouped as "other" so we don't learn noise

def add_text_signals(df):
    j = [llm_judge(n, a, c) for n, a, c in zip(df.customer_name, df.address, df.city)]
    df = df.copy()
    df["addr_unusable"] = [not x["address_usable"] for x in j]
    df["addr_vague"] = [bool(x.get("address_vague", False)) and x["address_usable"] for x in j]
    df["fake_name"] = [bool(x["fake_name"]) for x in j]
    return df

class RiskModel:
    def fit(self, df):
        df = add_text_signals(df) if "addr_unusable" not in df else df
        vc = df.city.value_counts()
        self.cities = sorted(vc[vc >= MIN_CITY_ORDERS].index)
        X = self._X(df)
        self.cols = list(X.columns)
        self.mu = X.mean()
        self.lr = LogisticRegression(C=0.5, max_iter=2000).fit(X, df.rto)
        self.base_rate = df.rto.mean()
        # historical stats used to write plain-English reasons
        self.city_stats = df.groupby("city").rto.agg(["mean", "count"])
        self.first_rate = df[df.customer_prior_orders == 0].rto.mean()
        self.repeat_rate = df[df.customer_prior_orders > 0].rto.mean()
        self.high_rate = df[df.order_value >= 1500].rto.mean()
        return self

    def _X(self, df):
        X = pd.DataFrame(index=df.index)
        for c in getattr(self, "cities", []):
            X["city_" + c] = (df.city == c).astype(float)
        X["first_time"] = (df.customer_prior_orders == 0).astype(float)
        X["good_repeat"] = ((df.customer_prior_orders > 0) & (df.customer_prior_rto == 0)).astype(float)
        X["prior_rto_1"] = (df.customer_prior_rto == 1).astype(float)
        X["prior_rto_2plus"] = (df.customer_prior_rto >= 2).astype(float)
        X["high_value"] = (df.order_value >= 1500).astype(float)
        X["tiny_value"] = (df.order_value < 300).astype(float)
        X["meta_ads"] = (df.utm_source == "meta_ads").astype(float)
        X["addr_unusable"] = df.addr_unusable.astype(float)
        X["addr_vague"] = df.addr_vague.astype(float)
        X["fake_name"] = df.fake_name.astype(float)
        X["bad_phone"] = (~df.phone_valid).astype(float)
        return X

    def predict(self, df):
        df = add_text_signals(df) if "addr_unusable" not in df else df
        return self.lr.predict_proba(self._X(df)[self.cols])[:, 1]

    def explain(self, row_df, k=3):
        """Top reasons this order is riskier than average, in words with the real numbers."""
        df = add_text_signals(row_df) if "addr_unusable" not in row_df else row_df
        x = self._X(df)[self.cols].iloc[0]
        contrib = (x - self.mu) * pd.Series(self.lr.coef_[0], index=self.cols)
        r = df.iloc[0]
        out = []
        for name, c in contrib.sort_values(ascending=False).items():
            if c < 0.10 or len(out) >= k:
                break
            out.append(self._phrase(name, r))
        return [o for o in out if o]

    def _phrase(self, name, r):
        if name.startswith("city_"):
            c = name[5:]; s = self.city_stats.loc[c]
            return f"{c} orders came back {s['mean']:.0%} of the time in our history ({int(s['count'])} orders)"
        return {
            "first_time": f"first-time customer (new buyers return {self.first_rate:.0%} vs {self.repeat_rate:.0%} for repeat buyers)",
            "prior_rto_1": "customer has returned an earlier order before",
            "prior_rto_2plus": f"customer has returned {int(r.customer_prior_rto)} earlier orders",
            "high_value": f"high-value COD order (Rs {int(r.order_value):,}; orders of Rs 1,500+ came back {self.high_rate:.0%})",
            "tiny_value": "very small order value",
            "meta_ads": "came from Meta ads (slightly higher return rate)",
            "addr_unusable": "address looks like a placeholder, courier cannot find it",
            "addr_vague": "address has no house number, landmark only",
            "fake_name": f"name looks fake ('{r.customer_name}')",
            "bad_phone": "phone number is not a valid 10-digit Indian mobile",
        }.get(name)
