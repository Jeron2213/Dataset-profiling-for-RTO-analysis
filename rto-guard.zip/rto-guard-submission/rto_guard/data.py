"""Load + clean orders. Every cleaning step is counted so the README/memo can report it."""
import re
import pandas as pd

def normalise_phone(p):
    digits = re.sub(r"\D", "", str(p))
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits

def load_orders(path, report=None):
    rep = report if report is not None else {}
    d = pd.read_csv(path, dtype={"phone": str})
    rep["rows_in"] = len(d)
    d["status"] = d.final_status.str.strip().str.upper()
    d = d.drop(columns=["final_status"])
    rep["in_transit_dropped"] = int((d.status == "IN_TRANSIT").sum())
    d = d[d.status != "IN_TRANSIT"]          # outcome unknown -> can't learn from it
    rep["duplicate_rows_dropped"] = int(d.duplicated("order_id").sum())
    d = d.drop_duplicates("order_id")
    d["rto"] = (d.status == "RTO").astype(int)
    d["phone_clean"] = d.phone.map(normalise_phone)
    d["phone_valid"] = d.phone_clean.str.match(r"^[6-9]\d{9}$")
    rep["invalid_phones"] = int((~d.phone_valid).sum())
    rep["missing_pincode"] = int(d.pincode.isna().sum())
    rep["zero_value_orders"] = int((d.order_value <= 0).sum())
    d["order_dt"] = pd.to_datetime(d.order_datetime)
    d["city"] = d.city.fillna("Unknown")
    d["pincode"] = d.pincode.astype("Int64")
    rep["rows_used"] = len(d)
    return d.reset_index(drop=True)
