"""Every number quoted in the memo comes from here (python run.py findings -> out/findings.md)."""
import numpy as np, pandas as pd
from . import economics as eco

def pct(x): return f"{x:.1%}"

def findings(df, cfg, rep):
    e = cfg["economics"]; L = eco.rto_loss(e); m = e["gross_margin"]
    out = []
    w = out.append
    w(f"# Findings (cleaned data: {len(df):,} COD orders, {df.order_dt.min():%d %b} - {df.order_dt.max():%d %b %Y})\n")
    w(f"Cleaning: {rep}\n")
    w(f"- Overall COD return rate: {pct(df.rto.mean())}. Average order value: Rs {df.order_value.mean():,.0f} (brief said Rs 649). Median Rs {df.order_value.median():,.0f}.")
    w(f"- Cash cost of one return: Rs {L:.1f}. Margin on a delivered Rs 649 order: Rs {m*649:.0f}. Break-even risk for shipping vs cancelling = m/(m+L): "
      f"{m*649/(m*649+L):.0%} at Rs 649, {m*df.order_value.mean()/(m*df.order_value.mean()+L):.0%} at the dataset average.\n")
    # geography
    c = df.groupby("city").rto.agg(["mean", "count"]).sort_values("mean")
    big = c[c["count"] >= 30]
    w("## Geography\n" + big.assign(mean=big["mean"].map(pct)).to_markdown())
    s = df.groupby("state").rto.agg(["mean", "count"]).sort_values("mean")
    w("\n" + s.assign(mean=s["mean"].map(pct)).to_markdown())
    pcs = df.groupby("pincode").size()
    w(f"\n- Distinct pincodes: {len(pcs):,} for {len(df):,} orders; median orders per pincode = {pcs.median():.0f}; pincodes with >=10 orders: {(pcs>=10).sum()}.")
    tr = df[df.order_dt < "2026-09-01"]; te = df[df.order_dt >= "2026-09-01"]
    pc = tr.groupby("pincode").rto.agg(["mean", "count"]); bad = pc[(pc["count"] >= 2) & (pc["mean"] >= 0.5)].index
    hit = te[te.pincode.isin(bad)]
    w(f"- Ops' pincode rule (>=2 past orders, >=50% returned) trained Apr-Aug, tested Sep: flags {len(bad)} pincodes; they covered {len(hit)} of {len(te)} September orders "
      f"({len(hit)/len(te):.0%}) and those came back {pct(hit.rto.mean())} vs {pct(te.rto.mean())} overall - no better than a coin flip vs the average.")
    t3 = ["Gorakhpur", "Bareilly", "Darbhanga", "Sagar", "Patna", "Kota", "Madhubani"]
    g = df[df.city.isin(t3)]
    w(f"- Smaller-city cluster ({', '.join(t3)}): {len(g)} orders ({len(g)/len(df):.0%} of orders), {pct(g.rto.mean())} return rate, "
      f"= {g.rto.sum()/df.rto.sum():.0%} of all returns.")
    mm = df[df.city.isin(["Mumbai", "Pune"])]
    w(f"- Mumbai+Pune: {len(mm)} orders, {pct(mm.rto.mean())} return rate.")
    # data quality / text
    junk = df[df.address.str.strip().str.len() <= 10]
    w(f"\n## Bad details\n- Placeholder addresses (<=10 chars: '.', 'xyz', 'home', 'call me'): {len(junk)} orders ({len(junk)/len(df):.1%}), {pct(junk.rto.mean())} returned, i.e. {pct(1-junk.rto.mean())} still delivered.")
    fk = df[df.customer_name.str.contains(r"asdf|test|qwerty|^na$|aaa|^abc$", case=False, regex=True)]
    w(f"- Fake-looking names (test/asdf/qwerty/na/aaa/abc): {len(fk)} orders, {pct(fk.rto.mean())} returned.")
    hing = df[df.address.str.contains(r"ke saamne|se left|se right|ke paas|ke peeche|ghar ka naam", case=False)]
    w(f"- Hinglish addresses ('ke saamne', 'ghar ka naam'...): {len(hing)} orders, {pct(hing.rto.mean())} returned vs {pct(df[~df.index.isin(hing.index)].rto.mean())} for others -> Hinglish itself is NOT a risk signal.")
    # customer history
    first = df[df.customer_prior_orders == 0]; rep_ = df[df.customer_prior_orders > 0]
    w(f"\n## Customers\n- First-time: {len(first)} orders ({len(first)/len(df):.0%} of COD), {pct(first.rto.mean())} returned. Repeat: {pct(rep_.rto.mean())}.")
    pr = df.groupby(df.customer_prior_rto.clip(upper=2)).rto.agg(["mean", "count"])
    w("- By prior returns (0/1/2+):\n" + pr.assign(mean=pr["mean"].map(pct)).to_markdown())
    nm = df[(df.customer_prior_orders == 0) & (df.utm_source == "meta_ads")]
    w(f"- First-time customers from Meta ads: {len(nm)} orders ({len(nm)/len(df):.0%}), {pct(nm.rto.mean())} returned. At Rs {e['acquisition_cost_meta']} CAC that is Rs {len(nm)*e['acquisition_cost_meta']:,} of ad spend on these orders.")
    # value
    vb = pd.cut(df.order_value, [-1, 0, 399, 999, 1499, 3000], labels=["Rs0", "<400", "400-999", "1000-1499", "1500+"])
    v = df.groupby(vb, observed=True).rto.agg(["mean", "count"])
    w("\n## Order value\n" + v.assign(mean=v["mean"].map(pct)).to_markdown())
    # courier
    cc = df.groupby("courier").rto.agg(["mean", "count"])
    tier = np.where(df.city.isin(["Mumbai", "Pune", "Delhi", "Chennai", "Bengaluru", "Hyderabad", "Kolkata"]), "metro", "other")
    cm = df.groupby([tier, "courier"]).rto.agg(["mean", "count"])
    w("\n## Couriers\n" + cc.assign(mean=cc["mean"].map(pct)).to_markdown() + "\n\nWithin metro / other:\n" + cm.assign(mean=cm["mean"].map(pct)).to_markdown())
    mo = df.groupby(df.order_dt.dt.strftime("%Y-%m")).rto.mean()
    w("\n## Trend\n" + ", ".join(f"{k}: {pct(v_)}" for k, v_ in mo.items()))
    return "\n".join(w_ if isinstance(w_, str) else str(w_) for w_ in out)
