"""Estimated Rs impact of each decision vs. just shipping it. Uses the risk score, NOT hindsight,
because on the day an order is decided its outcome is unknown. Lines reconcile exactly with economics.expected_value."""
import pandas as pd
from . import economics as eco
from .engine import SHIP, CONFIRM, NUDGE, HOLD

def order_impact(r, cfg):
    e, a = cfg["economics"], cfg["assumptions"]
    p, V = r.risk, r.order_value
    first = r.customer_prior_orders == 0
    L, m = eco.rto_loss(e), eco.margin(e, V)
    fut = a["first_order_future_value"] if first else 0
    out = dict(saved_rto=0.0, lost_genuine=0.0, discount_cost=0.0, extra_margin=0.0, msg_cost=0.0)
    if r.action == HOLD:
        out["saved_rto"] = p * L; out["lost_genuine"] = (1 - p) * (m + fut)
    elif r.action == CONFIRM:
        out["saved_rto"] = p * a["confirm_drops_would_be_rto"] * L
        out["lost_genuine"] = (1 - p) * a["confirm_drops_genuine"] * (m + fut)
        out["msg_cost"] = e["whatsapp_message_cost"]
    elif r.action == NUDGE:
        c, rr, d = a["nudge_conversion"], e["prepaid_rto_rate"], eco.prepaid_discount_rs(cfg, V)
        out["saved_rto"] = c * (p - rr) * L
        out["extra_margin"] = c * (p - rr) * (m + fut)       # would-be returns that now get delivered
        out["discount_cost"] = c * (1 - rr) * d
        out["msg_cost"] = e["whatsapp_message_cost"]
    out["net"] = out["saved_rto"] + out["extra_margin"] - out["lost_genuine"] - out["discount_cost"] - out["msg_cost"]
    return out

def summarise(df, cfg):
    imp = pd.DataFrame([order_impact(r, cfg) for r in df.itertuples()], index=df.index)
    counts = df.action.value_counts().reindex([SHIP, CONFIRM, NUDGE, HOLD]).fillna(0).astype(int)
    return counts, imp.sum()
