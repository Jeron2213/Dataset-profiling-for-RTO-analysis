"""Turns a risk score + hard rules + config thresholds into one of 4 actions with a plain-English reason."""
from . import economics as eco

SHIP, CONFIRM, NUDGE, HOLD = "SHIP_AS_IS", "CONFIRM_ON_WHATSAPP", "NUDGE_TO_PREPAID", "HOLD_CANCEL"
LABEL = {SHIP: "Ship as-is", CONFIRM: "Ship after confirmation", NUDGE: "Nudge to prepaid", HOLD: "Hold / cancel"}

def decide(row, p, reasons, cfg):
    t, g = cfg["thresholds"], cfg["guardrails"]
    first = row.customer_prior_orders == 0
    drivers = "; ".join(reasons[:3]) if reasons else "no strong risk signals"
    risk = f"{p:.0%} chance of return (average COD order: 28%)"

    # 1. Unusable details. Data says even these come back only ~60% of the time, so shipping them
    #    still beats cancelling on Rs. The money-making move is to ask the customer to fix them.
    bad = []
    if row.addr_unusable: bad.append("address is a placeholder the courier cannot use")
    if row.fake_name: bad.append(f"name looks fake ('{row.customer_name}')")
    if row.order_value <= 0:
        return _out(SHIP, p, "Order value is Rs 0 (replacement or gift?). No cash is at risk, so it ships; flagged for a quick check.", "zero_value")
    if bad and not row.phone_valid:
        return _out(HOLD, p, "Address/name unusable AND phone number invalid: we can neither deliver nor reach the customer. "
                    "Hold until ops gets corrected details (email/call).", "no_contact")
    if bad and g["ask_to_fix_unusable_details"]:
        return _out(CONFIRM, p, "Details unusable: " + "; ".join(bad) + ". WhatsApp the customer to confirm "
                    "their full address before shipping (these orders come back ~60% of the time, but ~40% are real buyers, so we ask instead of cancelling).",
                    "details_unusable")

    # 2. Repeat returner
    if row.customer_prior_rto >= g["repeat_returners_min_prior_rto"]:
        return _out(HOLD, p, f"Customer has already returned {int(row.customer_prior_rto)} orders; {risk}. "
                             "Cancel COD and offer a prepaid link instead.", "repeat_returner")

    # 3. Score thresholds
    if p >= t["cancel_above_risk"]:
        if g["never_auto_cancel_first_time"] and first:
            return _out(CONFIRM, p, f"Very risky ({risk}) but a first-time customer, so we confirm instead of cancelling. "
                                    f"Why: {drivers}.", "first_time_protected")
        return _out(HOLD, p, f"Very risky: {risk}. Why: {drivers}.", "score_cancel")
    if p >= t["confirm_above_risk"] and not row.phone_valid:
        return _out(HOLD, p, f"Risky: {risk}. Why: {drivers}. Phone number is invalid so WhatsApp confirmation is impossible: ops to call/email before shipping.", "no_contact")
    if p >= t["confirm_above_risk"]:
        return _out(CONFIRM, p, f"Risky: {risk}. Why: {drivers}. Customer must confirm on WhatsApp.", "score_confirm")
    if p >= t["nudge_above_risk"] and row.order_value >= t["nudge_min_order_value"] and row.phone_valid:
        d = eco.prepaid_discount_rs(cfg, row.order_value)
        return _out(NUDGE, p, f"Slightly above average risk: {risk}. Why: {drivers}. "
                              f"Offer Rs {d:.0f} off to pay online (prepaid orders return ~4%).", "score_nudge")
    return _out(SHIP, p, f"Low risk: {risk}. " + (f"Watch-outs: {drivers}." if reasons else "Nothing unusual."), "score_ship")

def _out(action, p, reason, rule):
    return {"action": action, "label": LABEL[action], "risk": float(p), "reason": reason, "rule": rule}
