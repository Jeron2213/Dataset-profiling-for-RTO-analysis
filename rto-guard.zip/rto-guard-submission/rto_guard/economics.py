"""All the Rs maths in one place. Pure functions, no ML."""

def rto_loss(e):
    """Cash lost every time a COD order comes back (excludes the sale we didn't make)."""
    return (e["forward_shipping"] + e["return_shipping"] + e["packaging_handling"]
            + e["damaged_share_of_returns"] * e["product_cost_if_damaged"])

def margin(e, value):
    return e["gross_margin"] * value

def prepaid_discount_rs(cfg, value):
    d = cfg["prepaid_discount"]
    return max(d["min_rupees"], min(d["max_rupees"], d["percent"] / 100 * value))

def expected_value(action, p, value, first_time, cfg):
    """Expected Rs profit of an action on one order, given risk p. Used for tuning/backtests.
    ship: sell and hope.  cancel: no sale, no loss (first-timer: we also forgo future value)."""
    e, a = cfg["economics"], cfg["assumptions"]
    L, m = rto_loss(e), margin(e, value)
    fut = a["first_order_future_value"] if first_time else 0
    wa = e["whatsapp_message_cost"]
    if action == "ship":
        return (1 - p) * (m + fut) - p * L
    if action == "cancel":
        return 0.0
    if action == "confirm":
        stay_bad = p * (1 - a["confirm_drops_would_be_rto"])
        stay_good = (1 - p) * (1 - a["confirm_drops_genuine"])
        return stay_good * (m + fut) - stay_bad * L - wa
    if action == "nudge":
        d = prepaid_discount_rs(cfg, value)
        c = a["nudge_conversion"]
        r = e["prepaid_rto_rate"]
        prepaid = (1 - r) * (m - d + fut) - r * L
        return c * prepaid + (1 - c) * ((1 - p) * (m + fut) - p * L) - wa
    raise ValueError(action)

def realised_value(action, rto, value, first_time, cfg):
    """Rs result of an action on an order whose true outcome we KNOW (backtest).
    Customer behaviour after a message is still assumed (see config 'assumptions')."""
    e, a = cfg["economics"], cfg["assumptions"]
    L, m = rto_loss(e), margin(e, value)
    fut = a["first_order_future_value"] if first_time else 0
    wa = e["whatsapp_message_cost"]
    ship = -L if rto else m + fut
    if action == "ship":
        return ship
    if action == "cancel":
        return 0.0
    if action == "confirm":
        drop = a["confirm_drops_would_be_rto"] if rto else a["confirm_drops_genuine"]
        return (1 - drop) * ship - wa
    if action == "nudge":
        d = prepaid_discount_rs(cfg, value)
        r = e["prepaid_rto_rate"]
        prepaid = (1 - r) * (m - d + fut) - r * L
        c = a["nudge_conversion"]
        return c * prepaid + (1 - c) * ship - wa
    raise ValueError(action)
