"""Prepaid discount maths. Prints the table that justifies config.yaml -> prepaid_discount."""
import yaml
from . import economics as eco

def breakeven_discount(p, V, cfg, first=False):
    """Largest discount (Rs) at which a customer who switches COD->prepaid is still worth as much as shipping COD."""
    e, a = cfg["economics"], cfg["assumptions"]
    L, m = eco.rto_loss(e), eco.margin(e, V)
    fut = a["first_order_future_value"] if first else 0
    cod = (1 - p) * (m + fut) - p * L
    r = e["prepaid_rto_rate"]
    # (1-r)*(m - d + fut) - r*L = cod  ->  d = m + fut - (cod + r*L)/(1-r)
    return m + fut - (cod + r * L) / (1 - r)

def table(cfg):
    rows = ["| Order value | Risk of return | Profit if shipped COD | Profit if paid online (no discount) | **Max discount we can afford** | Our offer | Offer as % of max |", "|---|---|---|---|---|---|---|"]
    e = cfg["economics"]; L = eco.rto_loss(e)
    for V in (449, 649, 1000, 1500):
        for p in (0.20, 0.30, 0.45):
            m = eco.margin(e, V); cod = (1 - p) * m - p * L; r = e["prepaid_rto_rate"]
            pre = (1 - r) * m - r * L
            mx = breakeven_discount(p, V, cfg); off = eco.prepaid_discount_rs(cfg, V)
            rows.append(f"| Rs {V} | {p:.0%} | Rs {cod:.0f} | Rs {pre:.0f} | Rs {mx:.0f} | Rs {off:.0f} | {off / mx:.0%} |")
    return "\n".join(rows)

if __name__ == "__main__":
    cfg = yaml.safe_load(open("config.yaml"))
    print(f"Cost of one return (cash): Rs {eco.rto_loss(cfg['economics']):.1f}")
    print(table(cfg))
