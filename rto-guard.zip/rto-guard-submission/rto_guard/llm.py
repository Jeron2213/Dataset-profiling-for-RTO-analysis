"""
WHERE THE LLM IS USED (and where it is not)
-------------------------------------------
LLM  : judging free text - is this address complete/plausible/real-looking? is this name fake?
       Hinglish landmarks ("Hanuman Mandir ke saamne, Station chowk se left") are exactly the
       messy text regexes are bad at.
CODE : everything with a right answer - phone format, pincode<->state match, order value,
       customer history, historical return rates, money maths, thresholds.
The LLM never chooses the action. It returns a small structured judgement that becomes
ONE input to the risk score. If it fails or no key is set, we fall back to the rules below
and the system keeps working (never block an order because an API call timed out).

Backends:  ANTHROPIC_API_KEY set + `pip install anthropic`  -> Claude (RTO_LLM_MODEL, default claude-haiku-5-5)
           otherwise                                        -> built-in heuristic (offline, deterministic)
NOTE: the Claude path was written to the SDK docs but not run in the build environment (no key);
      the heuristic path is what the tests and backtest exercise.
"""
import json, os, re, hashlib

JUNK_ADDR = re.compile(r"^(\.+|x+y?z*|na|n/?a|test|home|house|call me|none|nil|-+|address|delhi|mumbai|\d{0,3})$", re.I)
FAKE_NAME = re.compile(r"(asdf|qwer|test|dummy|^abc|^aaa|^xx|^na$|^n/?a$|fake|^\w{1,2}$)", re.I)

def heuristic_judge(name, address, city):
    a = (address or "").strip()
    n = (name or "").strip()
    issues = []
    if len(a) <= 10 or JUNK_ADDR.match(a):
        return {"address_usable": False, "address_issue": "address is a placeholder or far too short to deliver to",
                "fake_name": bool(FAKE_NAME.search(n)), "source": "heuristic"}
    has_house_or_number = bool(re.search(r"\d", a))
    has_landmark = bool(re.search(r"near|opp|ke saamne|ke paas|ke peeche|se left|se right|chowk|mandir|bank|school|station", a, re.I))
    if not has_house_or_number and not has_landmark:
        issues.append("no house number and no landmark")
    return {"address_usable": not issues, "address_issue": "; ".join(issues),
            "address_vague": (not has_house_or_number),   # soft signal: landmark-only address
            "fake_name": bool(FAKE_NAME.search(n)), "source": "heuristic"}

PROMPT = """You screen Cash-on-Delivery orders for an Indian D2C brand. Judge ONLY the text fields.
Name: {name}
Address: {address}
City: {city}
Reply with JSON only: {{"address_usable": bool (could a courier find this? Hinglish and landmark-style
addresses are normal and OK), "address_issue": short reason or "", "fake_name": bool (placeholder/keyboard
mash/"test", NOT merely uncommon Indian names)}}"""

_cache = {}

def llm_judge(name, address, city):
    key = hashlib.md5(f"{name}|{address}|{city}".encode()).hexdigest()
    if key in _cache:
        return _cache[key]
    out = None
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            import anthropic
            client = anthropic.Anthropic(timeout=8)
            msg = client.messages.create(
                model=os.environ.get("RTO_LLM_MODEL", "claude-haiku-5-5"), max_tokens=200,
                messages=[{"role": "user", "content": PROMPT.format(name=name, address=address, city=city)}])
            txt = msg.content[0].text
            out = json.loads(re.search(r"\{.*\}", txt, re.S).group(0))
            out["source"] = "llm"
            # cheap code-side sanity net: an LLM must not wave through an obvious placeholder
            if len((address or "").strip()) <= 10:
                out["address_usable"] = False
        except Exception:
            out = None                       # fall through to heuristic
    if out is None:
        out = heuristic_judge(name, address, city)
    _cache[key] = out
    return out
