import html, pandas as pd, numpy as np
from .impact import summarise
from .engine import SHIP, CONFIRM, NUDGE, HOLD, LABEL

def inr(x): return ("-" if x < 0 else "") + "₹" + f"{abs(x):,.0f}"

def build(res, cfg, day, out_path):
    """res: decided orders (with 'action','risk','reason'); day: the 'yesterday' date."""
    day = pd.Timestamp(day).normalize()
    y = res[res.order_dt.dt.normalize() == day]
    m30 = res[(res.order_dt.dt.normalize() > day - pd.Timedelta(days=30)) & (res.order_dt.dt.normalize() <= day)]
    cy, iy = summarise(y, cfg); c30, i30 = summarise(m30, cfg)
    pred, act = m30.risk.mean(), m30.rto.mean()
    drift = abs(pred - act)
    health = ("OK" if drift < 0.05 else "CHECK MODEL", "ok" if drift < 0.05 else "bad")
    colors = {SHIP: "#2e7d32", CONFIRM: "#1565c0", NUDGE: "#ef6c00", HOLD: "#c62828"}
    tiles = "".join(f'<div class=tile style="border-top:5px solid {colors[k]}"><div class=n>{cy[k]}</div><div class=l>{LABEL[k]}</div>'
                    f'<div class=s>{cy[k] / max(len(y), 1):.0%} · 30-day: {c30[k]}</div></div>' for k in (SHIP, CONFIRM, NUDGE, HOLD))
    def money(i, big=True):
        rows = [("Saved from avoided returns", i.saved_rto, "pos"),
                ("Margin on would-be returns that now get delivered (prepaid)", i.extra_margin, "pos"),
                ("Lost: cancelled / dropped orders that may have been genuine", -i.lost_genuine, "neg"),
                ("Prepaid discounts given", -i.discount_cost, "neg"),
                ("WhatsApp costs", -i.msg_cost, "neg")]
        body = "".join(f"<tr><td>{n}</td><td class={c}>{inr(v)}</td></tr>" for n, v, c in rows)
        return f"<table>{body}<tr class=tot><td>Net impact vs shipping everything as-is</td><td class={'pos' if i.net >= 0 else 'neg'}>{inr(i.net)}</td></tr></table>"
    watch = y[y.action.isin([HOLD, CONFIRM])].sort_values("risk", ascending=False).head(6)
    wl = "".join(f"<tr><td>{r.order_id}</td><td>{LABEL[r.action]}</td><td>{inr(r.order_value)}</td><td>{html.escape(r.reason)}</td></tr>" for r in watch.itertuples())
    page = f"""<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>COD Orders - Morning View</title><style>
:root{{--bg:#f6f7f9;--card:#fff;--ink:#1b1f24;--mute:#667;--pos:#2e7d32;--neg:#c62828;--line:#e3e6ea}}
@media(prefers-color-scheme:dark){{:root{{--bg:#14161a;--card:#1d2026;--ink:#e8eaed;--mute:#9aa;--pos:#66bb6a;--neg:#ef5350;--line:#30343b}}}}
body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}}main{{max-width:1000px;margin:auto;padding:20px 16px}}
h1{{font-size:22px;margin:0}}h2{{font-size:15px;margin:22px 0 8px;color:var(--mute);text-transform:uppercase;letter-spacing:.04em}}
.sub{{color:var(--mute)}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}}
.tile,.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px}}.n{{font-size:34px;font-weight:700}}.l{{font-weight:600}}.s{{color:var(--mute);font-size:13px}}
table{{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px}}td{{padding:8px 12px;border-bottom:1px solid var(--line);vertical-align:top}}
td:last-child{{text-align:right;white-space:nowrap}}.pos{{color:var(--pos);font-weight:600}}.neg{{color:var(--neg);font-weight:600}}.tot td{{font-weight:700;font-size:17px}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}@media(max-width:760px){{.two{{grid-template-columns:1fr}}}}
.pill{{padding:2px 10px;border-radius:99px;font-weight:700}}.ok{{background:#e8f5e9;color:#1b5e20}}.bad{{background:#ffebee;color:#b71c1c}}
.watch td:last-child{{text-align:left;white-space:normal}}.note{{font-size:12.5px;color:var(--mute);margin-top:6px}}</style></head><body><main>
<h1>COD orders - morning view</h1>
<div class=sub>Yesterday: {day:%A, %d %b %Y} · {len(y)} COD orders · estimates use the risk score, not outcomes (returns take ~10 days to show)</div>
<h2>Yesterday's orders by action</h2><div class=grid>{tiles}</div>
<div class=two><div><h2>Yesterday: ₹ impact</h2>{money(iy)}</div><div><h2>Last 30 days: ₹ impact</h2>{money(i30)}</div></div>
<div class=note>"Net impact" = what we gained or lost compared with shipping every COD order as-is. Customer-behaviour inputs (how many reply, how many pay online) are assumptions in config.yaml until we have 2 weeks of real data.</div>
<h2>Model health (30 days)</h2><div class=card>Predicted return rate <b>{pred:.1%}</b> vs actual <b>{act:.1%}</b> &nbsp;<span class="pill {health[1]}">{health[0]}</span>
<div class=note>If the gap grows beyond 5 points, the risk score has gone stale - retrain (python run.py backtest) before trusting the buckets.</div></div>
<h2>Orders to eyeball today</h2><table class=watch>{wl or '<tr><td>Nothing high-risk yesterday.</td></tr>'}</table>
</main></body></html>"""
    open(out_path, "w", encoding="utf-8").write(page)
    return dict(yesterday=len(y), counts=cy.to_dict(), net_y=iy.net, net_30=i30.net, i30=i30.to_dict(), pred=pred, act=act)
