import numpy as np, pandas as pd
from .model import RiskModel, add_text_signals
from .engine import decide, SHIP, CONFIRM, NUDGE, HOLD
from . import economics as eco

ACT = {SHIP: "ship", CONFIRM: "confirm", NUDGE: "nudge", HOLD: "cancel"}

def decide_all(df, model, cfg):
    df = add_text_signals(df)
    p = model.predict(df)
    out = []
    for i, (idx, r) in enumerate(df.iterrows()):
        reasons = model.explain(df.loc[[idx]])
        out.append(decide(r, p[i], reasons, cfg))
    res = pd.DataFrame(out, index=df.index)
    return pd.concat([df, res], axis=1)

def realised(df, cfg, action_col="action"):
    v = []
    for r in df.itertuples():
        a = ACT[getattr(r, action_col)]
        v.append(eco.realised_value(a, r.rto, r.order_value, r.customer_prior_orders == 0, cfg))
    return np.array(v)

def policy_ship_all(df, cfg):
    return sum(eco.realised_value("ship", r.rto, r.order_value, r.customer_prior_orders == 0, cfg) for r in df.itertuples())

def split_time(df, test_month="2026-09"):
    m = df.order_dt.dt.strftime("%Y-%m")
    return df[m < test_month].copy(), df[m == test_month].copy()
