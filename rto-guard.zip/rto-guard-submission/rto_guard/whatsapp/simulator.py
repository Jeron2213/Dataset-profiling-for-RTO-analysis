"""Run the WhatsApp flow on scripted scenarios (python run.py whatsapp-demo) or in a browser chat (python run.py chat)."""
import json, yaml
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from .flow import Conversation

ORDER = dict(order_id="KT104501", customer_name="Rahul Verma", state="Uttar Pradesh", city="Lucknow",
             order_value=649, items="Satin Bonnet|Scrunchies 6pk", address="Sector 12, Gomti Nagar")
T0 = datetime(2026, 10, 30, 14, 0)

def scenarios(cfg):
    S = []
    def sc(title, flow, events, order=None, end_hours=26):
        S.append((title, flow, events, order or ORDER, end_hours))
    sc("CONFIRM - customer says YES (Hinglish)", "confirm", [(0.3, "haan")])
    sc("CONFIRM - customer says NO", "confirm", [(1, "nahi chahiye")], order=dict(ORDER, state="Karnataka", customer_name="Priya Nair"))
    sc("CONFIRM - random reply, then random again -> human", "confirm", [(1, "kab aayega??"), (2, "??? call me")])
    sc("CONFIRM - random reply, then YES", "confirm", [(1, "price kya hai"), (1.2, "yes ok")])
    sc("CONFIRM - silence for 24h -> reminders then auto-cancel; late YES revives", "confirm", [(40, "yes sorry was travelling")])
    sc("NUDGE - customer takes prepaid offer", "nudge", [(0.5, "1")])
    sc("NUDGE - customer keeps COD", "nudge", [(0.5, "2")], order=dict(ORDER, state="Maharashtra", customer_name="Sneha Kulkarni"))
    sc("NUDGE - silence 24h -> ships as COD", "nudge", [])
    sc("FIX-ADDRESS - gives full address", "fix", [(2, "Flat 402, Shanti Apartments, Gomti Nagar, Lucknow 226010")],
       order=dict(ORDER, address="call me"))
    sc("ORDER PLACED AT 11:30pm -> first message at 8am", "confirm", [(10, "yes")])
    return S

def run_scenario(cfg, title, flow, events, order, end_hours, start=T0):
    start = datetime(2026, 10, 30, 23, 30) if "11:30pm" in title else start
    c = Conversation(dict(order), flow, cfg, start)
    for h, text in events:
        c.on_message(text, start + timedelta(hours=h + (8.5 if "11:30pm" in title else 0)))
    c.tick(start + timedelta(hours=end_hours + (8.5 if "11:30pm" in title else 0)))
    return c

def demo(cfg):
    for title, flow, events, order, end in scenarios(cfg):
        c = run_scenario(cfg, title, flow, events, order, end)
        print(f"\n=== {title}\n    language={c.lang}  first message scheduled {c.send_at:%a %H:%M}")
        for t, who, txt in c.log:
            print(f"  [{t:%a %H:%M}] {who:<8} {txt}")
        print(f"  --> RESULT: {c.final}")

PAGE = """<!doctype html><meta charset=utf-8><title>WhatsApp mock</title><meta name=viewport content="width=device-width">
<style>body{font:15px system-ui;background:#ece5dd;margin:0}#w{max-width:460px;margin:auto;height:100vh;display:flex;flex-direction:column}
#h{background:#075e54;color:#fff;padding:12px}#m{flex:1;overflow:auto;padding:10px}.b{max-width:80%;padding:8px 10px;margin:6px 0;border-radius:8px;white-space:pre-wrap}
.bot{background:#fff}.me{background:#dcf8c6;margin-left:auto}#f{display:flex;gap:6px;padding:8px;background:#f0f0f0}input{flex:1;padding:10px;border-radius:20px;border:1px solid #ccc}
select,button{padding:8px}.sys{text-align:center;font-size:12px;color:#555}</style>
<div id=w><div id=h>Order bot (mock) &nbsp; <select id=flow><option value=confirm>Confirm flow</option><option value=nudge>Prepaid nudge</option><option value=fix>Fix address</option></select>
<select id=skip><option value=0>+0h</option><option value=7>+7h (reminder 1)</option><option value=19>+19h (reminder 2)</option><option value=25>+25h (24h timeout)</option></select></div>
<div id=m></div><div id=f><input id=t placeholder="Type a reply: yes / nahi / random..." autofocus><button onclick=send()>Send</button></div></div>
<script>
let started=false;
async function api(body){let r=await fetch('/api',{method:'POST',body:JSON.stringify(body)});return r.json()}
function render(log){m.innerHTML=log.map(x=>x[1]=='SYS'?'<div class=sys>'+x[2]+'</div>':'<div class="b '+(x[1]=='BOT'?'bot':'me')+'">'+x[2]+'</div>').join('');m.scrollTop=1e9}
flow.onchange=async()=>{started=false;render((await api({reset:flow.value})).log)};
async function send(){if(!t.value)return;let r=await api({text:t.value,skip:+skip.value});t.value='';render(r.log)}
t.onkeydown=e=>{if(e.key=='Enter')send()};flow.onchange();
</script>"""

def serve(cfg, port=8765):
    state = {}
    def reset(flow):
        o = dict(ORDER)
        if flow == "fix": o["address"] = "call me"
        state["c"] = Conversation(o, flow, cfg, T0); state["flow"] = flow
        state["c"].tick(T0 + timedelta(minutes=6))
    reset("confirm")
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers(); self.wfile.write(PAGE.encode())
        def do_POST(self):
            b = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if "reset" in b: reset(b["reset"])
            else:
                c = state["c"]; now = T0 + timedelta(hours=b.get("skip", 0), minutes=7)
                c.on_message(b["text"], now)
            c = state["c"]
            log = [(str(t), who, txt) for t, who, txt in c.log]
            if c.final: log.append(("", "SYS", f"RESULT: {c.final}"))
            out = json.dumps({"log": log}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(out)
    print(f"WhatsApp mock chat on http://localhost:{port}  (Ctrl+C to stop)")
    HTTPServer(("", port), H).serve_forever()
