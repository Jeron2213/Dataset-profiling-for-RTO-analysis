"""
WhatsApp confirmation / prepaid-nudge flow (mock). Pure state machine: no network, injected clock,
so every scenario is testable and the same code could sit behind a real WhatsApp Cloud API webhook.

TIMELINE (all in config.yaml -> whatsapp)
  T+5 min   first message (if it's 10pm-8am, wait until 8am; the 24h clock starts when we send)
  T+6h      gentle reminder        T+18h  last-call reminder
  T+24h     no reply -> confirm flow: cancel (or ship, see config) | nudge flow: ship as COD

REPLIES
  yes/haan/ok/1        confirm flow: confirmed -> ship.   nudge flow: send prepaid link.
  no/nahi/cancel       confirm flow: cancel.               nudge flow: keep COD, ship (not a cancel!)
  address text         fix-address flow: we judge it; usable -> confirmed
  anything else        one clarification; second unclear reply -> human (ops queue)
  STOP                 opt-out, order goes to human
  late "yes" after auto-cancel -> reopened (a real customer who was just asleep shouldn't be lost)
"""
import re
from datetime import datetime, timedelta
from .. import economics as eco
from ..llm import llm_judge

YES = {"yes", "y", "yeah", "yep", "ok", "okay", "haan", "ha", "han", "haa", "ji", "confirm", "confirmed", "1", "sure", "theek hai", "thik hai", "👍", "pay", "paid"}
NO = {"no", "n", "nahi", "nahin", "nhi", "nope", "cancel", "mat bhejo", "2", "naa", "na", "👎", "cod"}
STOP = {"stop", "unsubscribe"}

T = {
 ("confirm", "en"): "Hi {name}! 👋 Thanks for your {brand} order #{id} ({items}, ₹{value}, Cash on Delivery). We ship only after confirmation. Reply *YES* to confirm or *NO* to cancel.",
 ("confirm", "hi"): "Namaste {name} 👋 {brand} ka aapka order #{id} ({items}, ₹{value}, Cash on Delivery) mil gaya. Dispatch se pehle confirm karna hai. Confirm ke liye *YES* bhejein, cancel ke liye *NO*.",
 ("fix", "en"): "Hi {name}! 👋 We got your {brand} order #{id} (₹{value}) but the address on it ('{addr}') is incomplete, so the courier can't find you. Please reply with your full address (house no., street, landmark, pincode) and we'll ship it right away.",
 ("fix", "hi"): "Namaste {name} 👋 {brand} ka aapka order #{id} (₹{value}) mila, lekin address ('{addr}') poora nahi hai, courier aap tak nahi pahunch payega. Kripya poora address bhejein (ghar no., gali, landmark, pincode) - hum turant ship kar denge.",
 ("nudge", "en"): "Hi {name}! 👋 Your {brand} order #{id} (₹{value}) is ready. Pay online now and get ₹{disc} OFF (pay ₹{pay} instead of ₹{value}) + priority dispatch. Reply *1* for the payment link, or *2* to keep Cash on Delivery.",
 ("nudge", "hi"): "Namaste {name} 👋 {brand} ka aapka order #{id} (₹{value}) ready hai. Abhi online pay karein aur ₹{disc} ki chhoot paayein (₹{value} ki jagah sirf ₹{pay}) + jaldi dispatch. Payment link ke liye *1* bhejein, Cash on Delivery ke liye *2*.",
 ("remind1", "en"): "Hi {name}, just a reminder about your order #{id}. Reply *YES* to confirm / *NO* to cancel.",
 ("remind1", "hi"): "Namaste {name}, order #{id} ka reminder. Confirm ke liye *YES*, cancel ke liye *NO* bhejein.",
 ("remind1_nudge", "en"): "Hi {name}, your order #{id} is waiting. Pay online and save ₹{disc} (reply *1*), or reply *2* to keep Cash on Delivery.",
 ("remind1_nudge", "hi"): "Namaste {name}, order #{id} intezaar kar raha hai. Online pay karke ₹{disc} bachayein (*1* bhejein) ya Cash on Delivery ke liye *2*.",
 ("remind2_nudge", "en"): "Last call 🙏 The ₹{disc} prepaid offer on order #{id} ends soon. Reply *1* to pay online, or we'll send it as Cash on Delivery.",
 ("remind2_nudge", "hi"): "Aakhri reminder 🙏 Order #{id} par ₹{disc} ki prepaid chhoot jaldi khatam hogi. Pay karne ke liye *1*, warna hum Cash on Delivery par bhej denge.",
 ("remind2", "en"): "Last call 🙏 Order #{id} will be {fate} in a few hours if we don't hear from you.",
 ("remind2", "hi"): "Aakhri reminder 🙏 Agar jawab nahi aaya to order #{id} kuch ghanton mein {fate} ho jayega.",
 ("unclear", "en"): "Sorry, I didn't get that 🙏 Please reply *YES* or *NO*.",
 ("unclear", "hi"): "Maaf kijiye, samajh nahi aaya 🙏 Kripya *YES* ya *NO* bhejein.",
 ("unclear_fix", "en"): "Thanks! Could you add house number / street / landmark / pincode? The courier needs them to reach you.",
 ("unclear_fix", "hi"): "Dhanyavaad! Kripya ghar no. / gali / landmark / pincode bhi bhejein, courier ko zaroorat hai.",
 ("ok_confirmed", "en"): "Thank you! ✅ Order #{id} is confirmed and will be dispatched shortly.",
 ("ok_confirmed", "hi"): "Dhanyavaad! ✅ Order #{id} confirm ho gaya, jaldi dispatch hoga.",
 ("ok_cancel", "en"): "No problem, order #{id} is cancelled. Hope to see you again! 🙏",
 ("ok_cancel", "hi"): "Theek hai, order #{id} cancel kar diya gaya hai. Phir milenge! 🙏",
 ("ok_cod", "en"): "Sure, keeping Cash on Delivery. Order #{id} will be dispatched shortly. ✅",
 ("ok_cod", "hi"): "Theek hai, Cash on Delivery hi rahega. Order #{id} jaldi dispatch hoga. ✅",
 ("paylink", "en"): "Great choice! 🎉 Pay ₹{pay} here: https://pay.example.com/{id}  (link valid 24h). We dispatch as soon as it's paid.",
 ("paylink", "hi"): "Badhiya! 🎉 ₹{pay} yahan pay karein: https://pay.example.com/{id}  (24 ghante valid). Payment hote hi dispatch.",
 ("expired_cancel", "en"): "We didn't hear back, so order #{id} has been cancelled. Reply YES within 48h to revive it.",
 ("expired_cancel", "hi"): "Jawab nahi aaya, isliye order #{id} cancel ho gaya. 48 ghante mein YES bhejein to wapas shuru kar denge.",
 ("expired_cod", "en"): "No worries! We're dispatching order #{id} as Cash on Delivery. 📦",
 ("expired_cod", "hi"): "Koi baat nahi! Order #{id} Cash on Delivery par dispatch ho raha hai. 📦",
 ("reopened", "en"): "Welcome back! Order #{id} is back on, confirmed and going out shortly. ✅",
 ("reopened", "hi"): "Wapas swagat hai! Order #{id} dobara shuru, confirm ho gaya. ✅",
 ("handoff", "en"): "Thanks - our team will contact you shortly. 🙏",
 ("handoff", "hi"): "Dhanyavaad - hamari team jaldi aapse sampark karegi. 🙏",
 ("optout", "en"): "Understood, you won't get further messages. Our team will confirm your order by phone.",
 ("optout", "hi"): "Theek hai, aage messages nahi aayenge. Hamari team phone par order confirm karegi.",
}

def pick_language(state, cfg):
    return "hi" if state in cfg["whatsapp"]["hindi_belt_states"] else "en"

def next_send_time(order_time, cfg):
    w = cfg["whatsapp"]
    t = order_time + timedelta(minutes=w["send_delay_minutes"])
    start, end = w["quiet_hours"]            # e.g. 22 -> 8
    if t.hour >= start or t.hour < end:
        t = t.replace(hour=end, minute=0, second=0) + (timedelta(days=1) if t.hour >= start else timedelta())
    return t

def classify(text, flow):
    t = re.sub(r"[^\w\s👍👎]", "", text.lower()).strip()
    if t in STOP: return "stop"
    if flow == "fix":
        return "address" if len(t) >= 8 and not (t in YES or t in NO) else ("no" if t in NO else "unclear")
    if t in YES: return "yes"
    if t in NO: return "no"
    if any(w in t.split() for w in ("yes", "haan", "confirm")) and not any(w in t.split() for w in ("no", "nahi", "cancel")): return "yes"
    if any(w in t.split() for w in ("no", "nahi", "cancel", "nahin")): return "no"
    return "unclear"

class Conversation:
    def __init__(self, order, flow, cfg, order_time):
        """order: dict(order_id, customer_name, state, order_value, items, address). flow: confirm|nudge|fix"""
        self.o, self.flow, self.cfg = order, flow, cfg
        self.lang = pick_language(order["state"], cfg)
        self.state = "SCHEDULED"
        self.outbox, self.log, self.unclear_count = [], [], 0
        self.send_at = next_send_time(order_time, cfg)
        self.sent_at = None
        self.reminders_sent = 0
        self.final = None                  # SHIP_COD | SHIP_PREPAID_PENDING | CANCELLED | HUMAN
        self.disc = eco.prepaid_discount_rs(cfg, order["order_value"])

    def _fmt(self, key, **kw):
        w = self.cfg["whatsapp"]
        v = self.o["order_value"]
        base = dict(name=self.o["customer_name"].split()[0], id=self.o["order_id"], value=f"{v:,.0f}", items=self.o.get("items", "your items").replace("|", ", "),
                    brand=w["brand_name"], disc=f"{self.disc:.0f}", pay=f"{v - self.disc:,.0f}", addr=self.o.get("address", ""),
                    fate="cancelled" if w["on_no_reply_confirmation"] == "cancel" and self.flow != "nudge" else "shipped")
        base.update(kw)
        return T[(key, self.lang)].format(**base)

    def _say(self, key, now, **kw):
        txt = self._fmt(key, **kw)
        self.outbox.append((now, txt)); self.log.append((now, "BOT", txt)); return txt

    def tick(self, now):
        w = self.cfg["whatsapp"]
        if self.state == "SCHEDULED" and now >= self.send_at:
            self._say(self.flow, self.send_at); self.sent_at = self.send_at; self.state = "AWAITING"
        if self.state != "AWAITING": return
        age = (now - self.sent_at).total_seconds() / 3600
        due = w["reminder_after_hours"]
        if self.reminders_sent == 0 and age >= due[0]:
            self._say("remind1_nudge" if self.flow == "nudge" else "remind1", self.sent_at + timedelta(hours=due[0])); self.reminders_sent = 1
        if self.reminders_sent == 1 and age >= due[1]:
            self._say("remind2_nudge" if self.flow == "nudge" else "remind2", self.sent_at + timedelta(hours=due[1]),
                      fate=self._fate()); self.reminders_sent = 2
        if age >= w["give_up_after_hours"]:
            t = self.sent_at + timedelta(hours=w["give_up_after_hours"])
            action = w["on_no_reply_nudge"] if self.flow == "nudge" else w["on_no_reply_confirmation"]
            if action == "ship":
                self._say("expired_cod", t); self._finish("SHIP_COD")
            else:
                self._say("expired_cancel", t); self._finish("CANCELLED", "EXPIRED")

    def _fate(self):
        return "cancelled" if self.cfg["whatsapp"]["on_no_reply_confirmation"] == "cancel" else "shipped"

    def _finish(self, final, state="DONE"):
        self.final, self.state = final, state

    def on_message(self, text, now):
        self.tick(now)
        self.log.append((now, "CUSTOMER", text))
        if self.state == "SCHEDULED": return
        if self.state == "EXPIRED":                      # late reply within 48h grace
            if (now - self.sent_at).total_seconds() / 3600 <= 72 and classify(text, "confirm") == "yes":
                self._say("reopened", now); self._finish("SHIP_COD", "DONE"); self.final = "SHIP_COD"
            return
        if self.state != "AWAITING": return
        kind = classify(text, self.flow)
        if kind == "stop":
            self._say("optout", now); self._finish("HUMAN"); return
        if self.flow == "nudge":
            if kind == "yes":
                self._say("paylink", now); self._finish("SHIP_PREPAID_PENDING"); return
            if kind == "no":
                if "cancel" in text.lower():
                    self._say("ok_cancel", now); self._finish("CANCELLED")
                else:
                    self._say("ok_cod", now); self._finish("SHIP_COD")
                return
        elif self.flow == "confirm":
            if kind == "yes": self._say("ok_confirmed", now); self._finish("SHIP_COD"); return
            if kind == "no": self._say("ok_cancel", now); self._finish("CANCELLED"); return
        elif self.flow == "fix":
            if kind == "no": self._say("ok_cancel", now); self._finish("CANCELLED"); return
            if kind == "address":
                j = llm_judge(self.o["customer_name"], text, self.o.get("city", ""))
                if j["address_usable"] and re.search(r"\d", text):
                    self.o["address"] = text
                    self._say("ok_confirmed", now); self._finish("SHIP_COD"); return
        # unclear
        self.unclear_count += 1
        if self.unclear_count >= 2:
            self._say("handoff", now); self._finish("HUMAN"); return
        self._say("unclear_fix" if self.flow == "fix" else "unclear", now)
